import { getStore } from '@netlify/blobs';
import { createHash, timingSafeEqual } from 'node:crypto';

const json = (data, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }
  });

const hash = s => createHash('sha256').update(String(s)).digest();
const pinConfere = (recebido, esperado) => timingSafeEqual(hash(recebido), hash(esperado));

export default async (req) => {
  const esperado = Netlify.env.get('PAULINHO_PIN');
  if (!esperado) return json({ erro: 'Variável PAULINHO_PIN não configurada no Netlify.' }, 500);

  if (!pinConfere(req.headers.get('x-pin') || '', esperado)) {
    return json({ erro: 'PIN inválido' }, 401);
  }

  const store = getStore('paulinho-coach');

  if (req.method === 'GET') {
    const alunos = await store.get('alunos', { type: 'json' });
    return json({ alunos: alunos ?? null });
  }

  if (req.method === 'PUT') {
    let body;
    try { body = await req.json(); } catch { return json({ erro: 'JSON inválido' }, 400); }
    const lista = body && body.alunos;
    if (!Array.isArray(lista) || lista.length > 2000 || !lista.every(a => a && typeof a === 'object')) {
      return json({ erro: 'Dados inválidos' }, 400);
    }
    await store.setJSON('alunos', lista);
    return json({ ok: true });
  }

  return json({ erro: 'Método não permitido' }, 405);
};

export const config = { path: '/api/alunos' };
